<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rating;
use App\Models\Package;
use App\Models\Service;
use App\Models\Reservation;
use Illuminate\Support\Facades\Auth;

class RatingController extends Controller
{
    public function index()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        $services = Service::all();
        $packages = Package::all();
        $reservations = Reservation::with(['ratings' => function($query) {
            $query->select('service_id', 'package_id', 'service_rating', 'package_rating', 'comment', 'reserv_id');
        }])->whereHas('ratings')->get();

        foreach ($reservations as $reservation) {
            $rating = $reservation->ratings->first();
            $reservation->serviceRating = $rating->service_rating ?? null;
            $reservation->packageRating = $rating->package_rating ?? null;
            $reservation->ratingComment = $rating->comment ?? null;
        }

        return view('reservations.reviews', compact('reservations', 'services', 'packages'));
    }

    public function submitRating(Request $request)
    {
        $request->validate([
            'reserv_id' => 'required|exists:reservations,id',
            'service_id' => 'required|exists:services,id',
            'package_id' => 'nullable|exists:packages,id',
            'service_rating' => 'required|integer|min:1|max:5',
            'package_rating' => 'nullable|integer|min:1|max:5',
            'comment' => 'nullable|string',
        ]);

        Rating::create([
            'reserv_id' => $request->input('reserv_id'),
            'user_id' => Auth::id(),
            'service_id' => $request->input('service_id'),
            'package_id' => $request->input('package_id') ?? null,
            'service_rating' => $request->input('service_rating'),
            'package_rating' => $request->input('package_rating') ?? null,
            'comment' => $request->input('comment') ?? null,
            'rated' => 1,
        ]);

        return response()->json(['message' => 'Rating submitted successfully'], 200);
    }

    public function store(Request $request)
    {
        $request->validate([
            'reservation_id' => 'required|exists:reservations,id',
            'images.*' => 'required|mimes:jpg,png,jpeg|max:10240',
        ]);

        $reservation = Reservation::find($request->input('reservation_id'));
        $uploadedImages = [];

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $imageName = time() . '-' . $image->getClientOriginalName();
                $image->move(public_path('receipts'), $imageName);
                $uploadedImages[] = $imageName;
            }
        }

        $existingImages = $reservation->receipt_image ? json_decode($reservation->receipt_image, true) : [];
        $allImages = array_merge($existingImages, $uploadedImages);

        $reservation->update([
            'receipt_image' => json_encode($allImages),
        ]);

        return redirect()->back()->with('success', 'Receipts uploaded successfully!');
    }

    public function stores(Request $request)
    {
        $request->validate([
            'reservation_id' => 'required|exists:reservations,id',
            'image' => 'required|mimes:jpg,png,jpeg|max:10240',
        ]);

        $newImageName = time() . '-' . $request->file('image')->getClientOriginalName();
        $request->file('image')->move(public_path('receipts'), $newImageName);

        $reservation = Reservation::find($request->input('reservation_id'));
        $reservation->update([
            'receipt_image' => $newImageName,
        ]);

        return redirect()->back()->with('success', 'Receipt uploaded successfully!');
    }
}