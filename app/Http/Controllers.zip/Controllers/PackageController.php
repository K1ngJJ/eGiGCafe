<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\PackageStoreRequest;
use App\Models\Service;
use App\Models\Package;
use App\Enums\PackageStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class PackageController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $package = Package::all();
        return view('packages.index', compact('package'));
    }

    public function create()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $services = Service::all();
        return view('packages.create', compact('services'));
    }

    public function store(PackageStoreRequest $request)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'image' => 'required|mimes:jpg,png,jpeg|max:10240',
            'guest_number' => 'required|integer',
            'status' => 'required',
            'price' => 'required|numeric'
        ]);

        $newImageName = time() . '-' . $request->image->getClientOriginalName();
        $request->image->move(public_path('packagesImages'), $newImageName);

        $package = Package::create([
            'name' => $request->name,
            'description' => $request->description,
            'image' => $newImageName,
            'guest_number' => $request->guest_number,
            'status' => $request->status,
            'price' => $request->price
        ]);

        if ($request->has('services')) {
            $package->services()->attach($request->services);
        }

        return redirect()->route('packages.index')->with('success', 'Package created successfully.');
    }

    public function show($id)
    {
        $package = Package::with(['package'])->findOrFail($id);
        return response()->json($package);
    }

    public function edit(Package $package)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $packages = Package::where('status', PackageStatus::Available)->get();
        $services = Service::all();

        return view('packages.edit', compact('package', 'services', 'packages'));
    }

    public function update(Request $request, Package $package)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'guest_number' => 'required|integer',
            'status' => 'required',
            'price' => 'required|numeric',
            'image' => 'nullable|mimes:jpg,png,jpeg|max:10240'
        ]);

        $image = $package->image;

        if ($request->hasFile('image')) {
            if ($image && File::exists(public_path('packagesImages/' . $image))) {
                File::delete(public_path('packagesImages/' . $image));
            }

            $newImageName = time() . '-' . $request->image->getClientOriginalName();
            $request->image->move(public_path('packagesImages'), $newImageName);
            $image = $newImageName;
        }

        $package->update([
            'name' => $request->name,
            'description' => $request->description,
            'image' => $image,
            'guest_number' => $request->guest_number,
            'status' => $request->status,
            'price' => $request->price
        ]);

        if ($request->has('services')) {
            $package->services()->sync($request->services);
        }

        return redirect()->route('packages.index')->with('success', 'Package updated successfully.');
    }

    public function destroy(Package $package)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        Storage::delete($package->image);
        $package->services()->detach();
        $package->delete();

        return redirect()->route('packages.index')->with('danger', 'Package deleted successfully.');
    }

    public function updateStatus(Request $request, $id)
    {
        if (auth()->user()->role == 'customer') {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        try {
            $package = Package::findOrFail($id);
            $status = $request->input('status');

            if (in_array($status, array_column(PackageStatus::cases(), 'value'))) {
                $package->status = $status;
                $package->save();

                return response()->json(['success' => true]);
            } else {
                return response()->json(['error' => 'Invalid status'], 400);
            }
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Package not found'], 404);
        }
    }
}
