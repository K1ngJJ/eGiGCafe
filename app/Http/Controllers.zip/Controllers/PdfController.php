<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Reservation;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;

class PdfController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function orderstxnPdf(Request $request)
    {
        if (auth()->user()->role === 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        ini_set('memory_limit', '512M');
        ini_set('max_execution_time', 300);

        $fromDate = $request->query('from');
        $toDate = $request->query('to');
        $typeFilter = $request->query('type');

        $query = Transaction::with(['order.user', 'discount'])
            ->whereHas('order', function ($query) {
                $query->where('completed', 1);
            });

        if ($typeFilter) {
            $query->whereHas('order', function ($query) use ($typeFilter) {
                $query->where('type', $typeFilter);
            });
        }

        if ($fromDate && $toDate) {
            $query->whereBetween('created_at', [$fromDate, $toDate]);
        }

        $orderstxn = $query->get()->map(function ($transaction) {
            $transaction->discount_id = $transaction->discount_id ?? 'No Discount';
            return $transaction;
        });

        $data = [
            'title' => 'Transactions Report',
            'date' => date('m/d/Y'),
            'orderstxn' => $orderstxn,
        ];

        $pdf = Pdf::loadView('reports.generate-orderstxn-pdf', $data);

        return $request->query('preview') ? $pdf->stream('OrdersTxn-data.pdf') : $pdf->download('OrdersTxn-data.pdf');
    }

    public function reservationstxnPdf(Request $request)
    {
        if (auth()->user()->role === 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        $query = Reservation::with('service', 'package');

        if ($request->filled('fromDate') && $request->filled('toDate')) {
            $query->whereBetween('res_date', [$request->fromDate, $request->toDate]);
        }

        if ($request->filled('eventType') && $request->eventType !== 'all') {
            $query->where('service_id', $request->eventType);
        }

        if ($request->filled('serviceType') && $request->serviceType !== 'all') {
            $query->where('cateringoption_id', $request->serviceType);
        }

        if ($request->filled('paymentMode') && $request->paymentMode !== 'all') {
            $query->where('payment_status', $request->paymentMode);
        }

        $reservationstxn = $query->get();

        $data = [
            'title' => 'Reservations Report',
            'date' => date('m/d/Y'),
            'reservationstxn' => $reservationstxn,
        ];

        $pdf = Pdf::loadView('reports.generate-reservationstxn-pdf', $data)->setPaper('a4', 'landscape');

        return $request->query('preview') ? $pdf->stream('ReservationsTxn-data.pdf') : $pdf->download('ReservationsTxn-data.pdf');
    }

    public function reservationPdf($id)
    {
        $reservation = Reservation::with('service', 'package')->findOrFail($id);

        $data = [
            'title' => 'Reservation Report',
            'date' => date('m/d/Y'),
            'reservation' => $reservation,
        ];

        $pdf = Pdf::loadView('reports.generate-reservation-pdf', $data)->setPaper([0, 0, 337, 840], 'portrait');

        return $pdf->download("Reservation-{$reservation->id}.pdf");
    }

    public function transactionPdf($id)
    {
        $transactions = Transaction::with('order.user', 'order.cartItems.menu')->findOrFail($id);

        $data = [
            'title' => 'Transaction Report',
            'date' => date('m/d/Y'),
            'transactions' => $transactions,
        ];

        \PDF::setOptions(['isHtml5ParserEnabled' => true, 'isUnicode' => true]);
        $pdf = \PDF::loadView('reports.generate-order-transaction-pdf', $data)->setPaper([0, 0, 267, 500]);

        return $pdf->download("Transaction-{$transactions->id}.pdf");
    }
}
