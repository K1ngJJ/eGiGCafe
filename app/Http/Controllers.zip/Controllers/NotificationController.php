<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Notifications;

class NotificationController extends Controller
{
    public function markNotification(Request $request)
    {
        $user = auth()->user();
        $notificationId = $request->input('id');

        if ($notificationId) {
            $notification = $user->unreadNotifications()->find($notificationId);
            if ($notification) {
                $notification->delete();
            }
        } else {
            $user->unreadNotifications->each(fn($notification) => $notification->delete());
        }

        return redirect()->back();
    }
}
