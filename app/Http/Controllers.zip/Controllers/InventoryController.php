<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Inventory;
use App\Models\User;
use App\Enums\UtensilStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use App\Events\InventoryStockUpdated;

class InventoryController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }
        $inventories = Inventory::all();
        return view('inventory.index', compact('inventories'));
    }

    public function create()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }
        return view('inventory.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'quantity' => 'required|integer',
            'initial_stock' => 'required|integer',
            'status' => 'required|string|in:Available,Unavailable',
            'price' => 'required|numeric|min:0.00|max:10000.00',
        ]);

        Inventory::create([
            'name' => $request->name,
            'quantity' => $request->quantity,
            'initial_stock' => $request->initial_stock,
            'status' => $request->status,
            'price' => $request->price,
        ]);

        return redirect()->route('inventory.index')->with('success', 'Item created successfully.');
    }

    public function show($id)
    {
        $inventory = Inventory::findOrFail($id);
        return response()->json($inventory);
    }

    public function edit(Inventory $inventory)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }
        return view('inventory.edit', compact('inventory'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string',
            'quantity' => 'required|integer',
            'initial_stock' => 'required|integer',
            'status' => 'required|string|in:Available,Unavailable',
            'price' => 'required|numeric|min:0.00|max:10000.00',
        ]);

        $inventory = Inventory::findOrFail($id);
        $inventory->update([
            'name' => $request->name,
            'quantity' => $request->quantity,
            'initial_stock' => $request->initial_stock,
            'status' => $request->status,
            'price' => $request->price,
        ]);

        $request->validate([
            'quantity' => 'required|integer|min:0',
        ]);

        $inventory->quantity = $request->quantity;

        event(new InventoryStockUpdated($inventory));

        $inventory->status = $inventory->quantity > 0 ? 'Available' : 'Unavailable';
        $inventory->save();

        return redirect()->route('inventory.index')->with('success', 'Item updated successfully.');
    }

    public function destroy(Inventory $inventory)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }
        $inventory->delete();
        return redirect()->route('inventory.index')->with('danger', 'Item deleted successfully.');
    }

    public function updateStatus(Request $request, $id)
    {
        if (auth()->user()->role == 'customer') {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        try {
            $inventory = Inventory::findOrFail($id);
            $status = $request->input('status');

            if (in_array($status, array_column(UtensilStatus::cases(), 'value'))) {
                $inventory->status = $status;
                $inventory->save();

                return response()->json(['success' => true]);
            } else {
                return response()->json(['error' => 'Invalid status'], 400);
            }
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Inventory item not found'], 404);
        }
    }

    public function utensilStatus(Request $request, $id)
    {
        if (auth()->user()->role == 'customer') {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $request->validate([
            'status' => 'required|string|in:Available,Unavailable',
        ]);

        try {
            $inventory = Inventory::findOrFail($id);
            $status = $request->input('status');

            $inventory->status = $status;
            $inventory->save();

            return response()->json(['success' => true, 'status' => $status]);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Inventory item not found'], 404);
        }
    }

    public function updateQuantity(Request $request, $id)
    {
        $request->validate([
            'quantity' => 'required|integer|min:0',
        ]);

        $inventory = Inventory::findOrFail($id);
        $inventory->quantity = $request->quantity;

        event(new InventoryStockUpdated($inventory));

        $inventory->status = $inventory->quantity > 0 ? 'Available' : 'Unavailable';
        $inventory->save();

        return response()->json([
            'success' => true,
            'quantity' => $inventory->quantity,
            'status' => $inventory->status,
        ]);
    }
}
