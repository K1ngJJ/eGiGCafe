<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Srmklive\PayPal\Services\PayPal as PayPalClient;
use App\Models\Order;
use App\Models\Discount;

class PayPalController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function processTransaction(Request $request, float $transactionAmount, int $orderId, int $discountID)
    {
        if ($transactionAmount < 0) {
            Order::where('id', $orderId)->first()->delete();
            return redirect()->route('cart')->with('error', 'Transaction amount must be more than ₱ 0.');
        }

        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $paypalToken = $provider->getAccessToken();

        $response = $provider->createOrder([
            "intent" => "CAPTURE",
            "application_context" => [
                "return_url" => route('successTransaction', [$transactionAmount, $orderId, $discountID]),
                "cancel_url" => route('cancelTransaction', $orderId),
            ],
            "purchase_units" => [
                0 => [
                    "amount" => [
                        "currency_code" => "PHP",
                        "value" => $transactionAmount
                    ]
                ]
            ]
        ]);

        if (isset($response['id']) && $response['id'] != null) {
            foreach ($response['links'] as $links) {
                if ($links['rel'] == 'approve') {
                    return redirect()->away($links['href']);
                }
            }

            Order::where('id', $orderId)->first()->delete();
            return redirect()->route('cart')->with('error', 'Something went wrong.');
        }

        Order::where('id', $orderId)->first()->delete();
        return redirect()->route('cart')->with('error', $response['message'] ?? 'Something went wrong.');
    }

    public function successTransaction(Request $request, float $transactionAmount, int $orderId, int $discountID)
    {
        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $provider->getAccessToken();
        $response = $provider->capturePaymentOrder($request['token']);

        if (isset($response['status']) && $response['status'] == 'COMPLETED') {
            $order = Order::where('id', $orderId)->first();
            $carts = auth()->user()->cartItems()->where('order_id', null)->get();
            
            foreach ($carts as $cart) {
                $cart->order()->associate($order);
                $cart->save();
            }

            $transactionData = [
                'final_amount' => $transactionAmount,
                'user_id' => auth()->id(),
            ];

            $order->transaction()->create($transactionData);

            if ($discountID != -1) {
                $discount = Discount::where("id", $discountID)->first();
                $order->transaction->discount()->associate($discount);
                $order->transaction->save();
            }

            return redirect()->route('cart')->with('success', 'Transaction complete.');
        }

        $order = Order::where('id', $orderId)->first();
        if ($order) {
            $order->delete();
        }

        return redirect()->route('cart')->with('error', 'Something went wrong.');
    }

    public function cancelTransaction(Request $request, int $orderId)
    {
        Order::where('id', $orderId)->first()->delete();
        return redirect()->route('cart')->with('error', 'You have canceled the transaction.');
    }
}
