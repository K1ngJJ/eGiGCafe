<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Menu;
use App\Models\MenuRating;
use File;
use Auth;

class MenuController extends Controller
{
    public function index()
    {
        $layout = (Auth::check() && auth()->user()->role != 'customer') ? 'layouts.backend' : 'layouts.app';
        $menus = Menu::get();
        return view('menu', compact('menus', 'layout'));
    }

    public function store(Request $request)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $request->validate([
            'menuName' => 'required',
            'menuDescription' => 'required',
            'menuPrice' => 'required|regex:/^\d+(\.\d{1,2})?/',
            'menuEstCost' => 'required|regex:/^\d+(\.\d{1,2})?/',
            'menuSize' => 'required',
            'menuImage' => 'required|mimes:jpg,png,jpeg|max:10240'
        ]);
        
        $newImageName = time() . '-' . $request->menuName . '.' . $request->menuImage->extension();
        $request->menuImage->move(public_path('menuImages'), $newImageName);

        $newMenuItem = new Menu();
        $newMenuItem->fill($request->only([
            'menuType', 'menuName', 'menuDescription', 'menuPrice', 'menuEstCost', 'menuSize', 'menuAllergic', 'menuVegetarian', 'menuVegan'
        ]));
        $newMenuItem->image = $newImageName;
        $newMenuItem->save();
        
        return redirect('/menu/filter?menuType=');
    }

    public function showDetails($id)
    {
        return view('editMenuDetails', ['menu' => Menu::find($id)]);
    }

    public function showImages($id)
    {
        return view('editMenuImages', ['menu' => Menu::find($id)]);
    }

    public function updateDetails(Request $request)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        $request->validate([
            'menuName' => 'required',
            'menuDescription' => 'required',
            'menuPrice' => 'required|regex:/^\d+(\.\d{1,2})?/',
            'menuEstCost' => 'required|regex:/^\d+(\.\d{1,2})?/',
            'menuSize' => 'required',
        ]);
        
        $menu = Menu::find($request->menuID);
        $menu->fill($request->only(['menuType', 'menuName', 'menuDescription', 'menuPrice', 'menuEstCost', 'menuSize', 'menuAllergic', 'menuVegetarian', 'menuVegan']));
        $menu->save();

        return redirect()->route('menu');
    }

    public function updateImages(Request $request)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }

        if ($request->hasFile('menuImage')) {
            $menu = Menu::find($request->menuID);

            $request->validate(['menuImage' => 'required|mimes:jpg,png,jpeg|max:10240']);
            
            $imagePath = 'menuImages/' . $menu->image;
            if (File::exists($imagePath)) {
                File::delete($imagePath);
            }

            $newImageName = time() . '-' . $menu->name . '.' . $request->menuImage->extension();
            $request->menuImage->move(public_path('menuImages'), $newImageName);

            $menu->image = $newImageName;
            $menu->save();
        }
        
        return redirect()->route('menu');
    }

    public function filter(Request $request)
    {
        $menu = Menu::query();

        if ($request->filled('rating')) {
            $menu->whereHas('ratings', function ($query) use ($request) {
                $query->havingRaw('AVG(rating) >= ?', [$request->rating]);
            });
        }

        foreach (['menuType' => 'type', 'fromPrice' => '>=', 'toPrice' => '<=', 'menuSize' => 'size', 'menuVegan' => 'vegan', 'menuVegetarian' => 'vegetarian', 'menuAllergic' => 'allergic'] as $key => $column) {
            if ($request->filled($key)) {
                $menu->where($column, $request->$key);
            }
        }

        return view('menu', ['menus' => $menu->get()]);
    }

    public function delete($id)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staffs.');
        }
        
        $menu = Menu::find($id);
        $imagePath = 'menuImages/' . $menu->image;
        if (File::exists($imagePath)) {
            File::delete($imagePath);
        }
        $menu->delete();
        
        return redirect()->route('menu');
    }

    public function showMenu()
    {
        $menus = Menu::with('menuRatings')->get();
    
        foreach ($menus as $menu) {
            $menu->averageRating = $menu->menuRatings->avg('rating') ?? 0;
            $menu->customerCount = $menu->menuRatings->count();
            $menu->commentCount = $menu->menuRatings->whereNotNull('comment')->count();
        }
    
        return view('menu', compact('menus'));
    }

    public function getComments($menuId)
    {
        $menu = Menu::with(['ratings.user'])->findOrFail($menuId);
        
        return response()->json([
            'ratings' => $menu->ratings->whereNotNull('comment')->map(function ($rating) {
                return [
                    'user' => $rating->user,
                    'comment' => $rating->comment,
                    'rating' => $rating->rating,
                    'created_at' => $rating->created_at->format('F j, Y'),
                ];
            })->values(),
        ]);
    }
}
