<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Support\Facades\Mail;
use App\Mail\NotifReservation;
use Illuminate\Support\Facades\Session;
use App\Enums\PackageStatus;
use App\Enums\UtensilStatus;
use App\Http\Controllers\Controller;
use App\Models\Reservation;
use App\Models\Package;
use App\Models\Service;
use App\Models\CateringOptions;
use App\Models\User;
use App\Models\Inventory;
use App\Rules\DateBetween;
use App\Rules\TimeBetween;
use Carbon\Carbon;
use App\Models\Transaction;
use DateInterval;
use DatePeriod;
use DateTime;
use App\Events\InventoryStockUpdated;
use App\Models\Order;
use Illuminate\Http\Request;
use App\Rules\OneReservationPerDay;
use App\Rules\UniqueReservationDate;
use Illuminate\Support\Facades\DB;

class ReservationController extends Controller
{
    public function __construct() {
        return $this->middleware('auth');
    }

    public function history()
    {
        $user = auth()->user();

        if ($user->role !== 'customer') {
            abort(403, 'This route is only meant for customers.');
        }

        $reservations = Reservation::where('email', $user->email)
                                   ->where('status', '!=', 'Cancelled')
                                   ->with('rating')
                                   ->get();

        return view('reservations.history', [
            'reservations' => $reservations
        ]);
    }

    public function cancelReservation($id)
    {
        $reservation = Reservation::findOrFail($id);
        $user = auth()->user();

        if ($reservation->email !== $user->email) {
            abort(403, 'Unauthorized action.');
        }

        $reservation->delete();

        return redirect()->route('reservations.history')->with('success', 'Reservation has been cancelled and removed.');
    }

    public function stepOne(Request $request)
    {
        if (auth()->user()->role != 'customer')
            abort(403, 'This route is only meant for customers.');

        $bestReservationMonth = Reservation::selectRaw('MONTH(res_date) as month, COUNT(*) as count')
            ->where('status', 'Fulfilled')
            ->groupBy('month')
            ->orderByDesc('count')
            ->first();

        $reservationMonthData = $bestReservationMonth ? [
            'month' => $bestReservationMonth->month,
            'count' => $bestReservationMonth->count,
        ] : null;

        $lastMonthDate = Carbon::now()->subDays(30)->toDateTimeString();
        $today = Carbon::today()->toDateString();
        $oneMonthTransactions = Transaction::where('created_at', '>=', $lastMonthDate)->get();

        $reservation = $request->session()->get('reservation');
        $min_date = Carbon::today();
        $max_date = Carbon::now()->addWeek();
        return view('reservations.step-one', compact('reservation', 'min_date', 'max_date', "reservationMonthData"));
    }

    public function storeStepOne(Request $request)
    {
        if (auth()->user()->role != 'customer') {
            abort(403, 'This route is only meant for customers.');
        }

        $user = auth()->user();

        $validated = $request->validate([
            'first_name' => ['required'],
            'last_name' => ['required'],
            'res_date' => ['required', 'date', new OneReservationPerDay($user->email), new TimeBetween(), new UniqueReservationDate($user->role)],
            'tel_number' => ['required'],
            'guest_number' => ['required', 'integer', 'min:1'],
            'venue_address' => ['required'],
            'agreement' => ['accepted'],
        ]);

        $validated['email'] = $user->email;
        $validated['user_id'] = $user->id;
        $validated['role'] = $user->role;

        if (empty($request->session()->get('reservation'))) {
            $reservation = new Reservation();
            $reservation->fill($validated);
            $request->session()->put('reservation', $reservation);
        } else {
            $reservation = $request->session()->get('reservation');
            $reservation->fill($validated);
            $request->session()->put('reservation', $reservation);
        }

        return redirect()->route('reservations.step.two');
    }

    public function stepTwo(Request $request)
    {
        if (auth()->user()->role != 'customer') {
            abort(403, 'This route is only meant for customers.');
        }

        $bestReservationMonth = Reservation::selectRaw('MONTH(res_date) as month, COUNT(*) as count')
            ->where('status', 'Fulfilled')
            ->groupBy('month')
            ->orderByDesc('count')
            ->first();

        $reservationMonthData = $bestReservationMonth ? [
            'month' => $bestReservationMonth->month,
            'count' => $bestReservationMonth->count,
        ] : null;

        $reservation = $request->session()->get('reservation');

        $res_package_ids = [];
        if ($reservation && $reservation->packages) {
            $res_package_ids = $reservation->packages->pluck('id')->toArray();
        }

        $inventories = Inventory::where('status', '!=', UtensilStatus::Unavailable->value)->get();
        $packages = Package::where('status', PackageStatus::Available)
            ->where('guest_number', '>=', $reservation->guest_number)
            ->whereNotIn('id', $res_package_ids)
            ->get();

        $services = Service::all();
        $cateringoptions = CateringOptions::all();

        return view('reservations.step-two', compact('reservation', 'packages', 'services', 'inventories', 'cateringoptions', "reservationMonthData"));
    }

    public function storeStepTwo(Request $request)
    {
        if (auth()->user()->role !== 'customer') {
            abort(403, 'This route is only meant for customers.');
        }

        $validated = $request->validate([
            'package_id' => ['nullable', 'exists:packages,id'],
            'service_id' => ['required', 'exists:services,id'],
            'cateringoption_id' => ['required', 'exists:catering_options,id'],
            'payment_status' => ['nullable', 'string'],
            'payment_selection' => ['nullable', 'string'],
            'theme_type' => ['nullable', 'string'],
            'main_color' => ['nullable', 'string'],
            'sub_color' => ['nullable', 'string'],
            'custom_main_color' => ['nullable', 'string'],
            'custom_sub_color' => ['nullable', 'string'],
            'theme_comments' => ['nullable', 'string'],
            'agreement' => ['accepted'],
        ]);

        $reservation = $request->session()->get('reservation');

        if (!$reservation) {
            return redirect()->route('reservations.step.one')->withErrors('Reservation data is missing.');
        }

        $reservation->fill($validated);
        $reservation->package_id = $request->input('package_id') ?: null;
        $reservation->payment_selection = $request->input('payment_selection') ?: null;
        $reservation->receipt_image = json_encode([]);

        $utensils = $request->input('utensils', []);
        $supplyDetails = [];
        $totalPrice = 0;
        $hasUtensilsSelected = false;

        if (is_array($utensils)) {
            foreach ($utensils as $utensilId => $utensilData) {
                if (!empty($utensilData['selected'])) {
                    $quantity = isset($utensilData['quantity']) ? (int)$utensilData['quantity'] : 0;

                    if ($quantity > 0) {
                        $hasUtensilsSelected = true;
                        $inventory = Inventory::find($utensilId);

                        if ($inventory) {
                            $totalPriceForUtensil = $quantity * $inventory->price;
                            $totalPrice += $totalPriceForUtensil;

                            if ($inventory->quantity >= $quantity) {
                                $inventory->quantity -= $quantity;
                                $inventory->save();

                                if ($inventory->quantity <= 0 || $inventory->quantity <= ($inventory->initial_stock * 0.3)) {
                                    event(new InventoryStockUpdated($inventory));
                                }

                                $supplyDetails[] = [
                                    'name' => $inventory->name,
                                    'quantity' => $quantity,
                                    'total_price' => $totalPriceForUtensil
                                ];
                            } else {
                                return redirect()->route('reservations.step.two')
                                                 ->withErrors("Insufficient stock for {$inventory->name}");
                            }
                        }
                    }
                }
            }
        }

        if (!$hasUtensilsSelected) {
            $supplyDetails = [];
        }

        $reservation->supply_details = json_encode($supplyDetails);
        $reservation->supply_total = $totalPrice;

        $reservation->theme_type = $request->input('theme_type');
        $reservation->main_color = $request->input('main_color');
        $reservation->sub_color = $request->input('sub_color');
        $reservation->custom_main_color = $request->input('custom_main_color');
        $reservation->custom_sub_color = $request->input('custom_sub_color');
        $reservation->theme_comments = $request->input('theme_comments');

        $reservation->save();

        Session::put('reservation_step_two_completed', true);
        $request->session()->forget('reservation');

        return redirect()->route('reservations.thankyou');
    }

    public function show($id)
    {
        $reservation = Reservation::with(['service', 'package'])->findOrFail($id);
        return response()->json($reservation);
    }

    public function thankyou()
    {
        $user = auth()->user();

        if (!Session::has('reservation_notification_sent')) {
            if ($user->role != 'customer') {
                abort(403, 'This route is only meant for customers.');
            }

            Session::put('reservation_step_two_completed', false);
            Session::flash('reservation_notification_sent', true);
        }

        $latestReservation = Reservation::where('email', $user->email)
                                        ->where('status', '!=', 'Fulfilled')
                                        ->latest()
                                        ->first();

        return view('reservations.thankyou', [
            'latestReservation' => $latestReservation,
            'payment_status' => $latestReservation ? $latestReservation->payment_status : null,
        ]);
    }
}
