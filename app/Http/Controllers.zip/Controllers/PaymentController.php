<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Omnipay\Omnipay;
use App\Models\Payment;
use App\Models\Reservation;

class PaymentController extends Controller
{
    private $gateway;

    public function __construct()
    {
        $this->gateway = Omnipay::create('PayPal_Rest');
        
        if (env('PAYPAL_MODE') === 'live') {
            $this->gateway->setClientId(env('PAYPAL_LIVE_CLIENT_ID'));
            $this->gateway->setSecret(env('PAYPAL_LIVE_CLIENT_SECRET'));
        } else {
            $this->gateway->setClientId(env('PAYPAL_SANDBOX_CLIENT_ID'));
            $this->gateway->setSecret(env('PAYPAL_SANDBOX_CLIENT_SECRET'));
        }
    
        $this->gateway->setTestMode(env('PAYPAL_MODE') !== 'live');
        $this->middleware('auth');
    }

    public function index()
    {
        $user = auth()->user();
        if ($user->role !== 'customer') {
            abort(403, 'This route is only meant for customers.');
        }
    
        $latestReservation = Reservation::where('email', $user->email)
            ->where('status', '!=', 'Fulfilled')
            ->latest()
            ->first();
    
        $paymentStatus = $latestReservation ? $latestReservation->payment_status : null;
        return view('reservations.thankyou', [
            'latestReservation' => $latestReservation,
            'paymentStatus' => $paymentStatus
        ]);
    }

    public function charge(Request $request)
    {
        if (auth()->user()->role !== 'customer') {
            abort(403, 'This route is only meant for customers.');
        }

        $request->validate([
            'reservation_id' => 'required|exists:reservations,id',
            'amount' => 'required|numeric|min:0.01',
        ]);

        $reservationId = $request->input('reservation_id');

        if ($request->input('submit')) {
            try {
                $response = $this->gateway->purchase([
                    'amount' => $request->input('amount'),
                    'currency' => env('PAYPAL_CURRENCY'),
                    'returnUrl' => url('success'),
                    'cancelUrl' => url('error'),
                ])->send();

                if ($response->isRedirect()) {
                    $request->session()->put('payment_details', [
                        'amount' => $request->input('amount'),
                        'reservation_id' => $reservationId,
                    ]);

                    $response->redirect();
                } else {
                    return back()->withErrors(['error' => $response->getMessage()]);
                }
            } catch (Exception $e) {
                return back()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    public function success(Request $request)
    {
        if (auth()->user()->role !== 'customer') {
            abort(403, 'This route is only meant for customers.');
        }
    
        $paymentDetails = $request->session()->get('payment_details');
    
        if ($request->input('paymentId') && $request->input('PayerID') && $paymentDetails) {
            try {
                $transaction = $this->gateway->completePurchase([
                    'payer_id' => $request->input('PayerID'),
                    'transactionReference' => $request->input('paymentId'),
                ])->send();
    
                if ($transaction->isSuccessful()) {
                    $data = $transaction->getData();
    
                    $payment = new Payment();
                    $payment->payment_id = $data['id'];
                    $payment->payer_id = $data['payer']['payer_info']['payer_id'];
                    $payment->payer_email = $data['payer']['payer_info']['email'];
                    $payment->amount = $paymentDetails['amount'];
                    $payment->currency = env('PAYPAL_CURRENCY');
                    $payment->payment_status = $data['state'];
                    $payment->reservation_id = $paymentDetails['reservation_id'];
                    $payment->save();
    
                    $reservation = Reservation::find($paymentDetails['reservation_id']);
                    $reservation->payment_status = $paymentDetails['payment_status'];
                    $reservation->save();
    
                    return redirect()->route('reservations.thankyou')->with('success', 'Payment successful! Transaction ID: ' . $data['id']);
                } else {
                    return back()->withErrors(['error' => $transaction->getMessage()]);
                }
            } catch (\Exception $e) {
                return back()->withErrors(['error' => $e->getMessage()]);
            }
        } else {
            return back()->withErrors(['error' => 'Transaction declined or invalid session data.']);
        }
    }

    public function error()
    {
        if (auth()->user()->role !== 'customer') {
            abort(403, 'This route is only meant for customers.');
        }

        return redirect()->route('reservations.thankyou')
            ->with('error', 'User cancelled the payment.');
    }
}
