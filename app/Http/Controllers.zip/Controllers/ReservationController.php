<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Requests\ReservationStoreRequest;
use App\Models\{Reservation, Package, Service, Inventory, CateringOptions, User};
use App\Enums\{PackageStatus, ReservationStatus};
use App\Mail\NotifReservation;
use App\Notifications\ReservationStatusNotification;

class ReservationController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        return view('reservations.index', [
            'reservations' => Reservation::all(),
            'services' => Service::all(),
            'packages' => Package::all(),
        ]);
    }

    public function create()
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        return view('reservations.create', [
            'services' => Service::all(),
            'inventories' => Inventory::all(),
            'cateringoptions' => CateringOptions::all(),
        ]);
    }

    public function store(ReservationStoreRequest $request)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        try {
            $reservation = new Reservation($request->validated());
            $reservation->status = ReservationStatus::Pending;
            $reservation->inventory_supplies = '';
            $reservation->save();

            return redirect()->route('reservations.index')->with('success', 'Reservation created successfully.');
        } catch (ModelNotFoundException $e) {
            return back()->with('error', 'An error occurred while creating the reservation.');
        }
    }

    public function show($id)
    {
        return response()->json(Reservation::with(['service', 'package'])->findOrFail($id));
    }

    public function edit($id)
    {
        return view('reservations.edit', [
            'reservation' => Reservation::findOrFail($id),
            'services' => Service::all(),
            'packages' => Package::all(),
            'inventories' => Inventory::all(),
            'cateringOptions' => CateringOptions::all(),
            'paymentStatuses' => \App\Enums\PaymentStatus::cases(),
        ]);
    }

    public function update(Request $request, $id)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }

        try {
            $reservation = Reservation::findOrFail($id);
            $reservation->fill($request->except(['inventory_supplies']));
            $reservation->package_id = $request->input('package_id') ?: null;

            if (in_array($request->status, ReservationStatus::cases())) {
                $reservation->status = ReservationStatus::from($request->status);
                $reservation->save();
            }

            if (in_array($reservation->status, ['Declined', 'Approved', 'Pending', 'In Progress', 'Fulfilled'])) {
                Mail::to($reservation->email)->send(new NotifReservation($reservation->status));
            }

            $request->session()->put('reservation', $reservation);
            return redirect()->route('reservations.index')->with('success', 'Reservation updated successfully.');
        } catch (ModelNotFoundException $e) {
            return back()->with('error', 'Reservation not found.');
        }
    }

    public function destroy(Reservation $reservation)
    {
        if (auth()->user()->role == 'customer') {
            abort(403, 'This route is only meant for restaurant staff.');
        }
        
        $reservation->delete();
        return redirect()->route('reservations.index')->with('warning', 'Reservation deleted successfully.');
    }

    public function updateStatus(Request $request, $id)
    {
        if (auth()->user()->role == 'customer') {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        try {
            $reservation = Reservation::findOrFail($id);
            $status = $request->input('status');

            if (in_array($status, ReservationStatus::cases())) {
                $reservation->status = $status;
                $reservation->save();
                Mail::to($reservation->email)->send(new NotifReservation($reservation->status));
                return response()->json(['success' => true]);
            }

            return response()->json(['error' => 'Invalid status'], 400);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Reservation not found'], 404);
        }
    }

    public function filterReservation(Request $request)
    {
        $query = Reservation::query();

        if ($request->filled('id')) $query->where('id', $request->id);
        if ($request->filled('startDate') && $request->filled('endDate')) {
            $query->whereBetween('res_date', [$request->startDate, $request->endDate]);
        }
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('payment_status')) $query->where('payment_status', $request->payment_status);
        if ($request->filled('service')) {
            $query->whereHas('service', fn($q) => $q->where('name', $request->service));
        }
        if ($request->filled('package')) {
            $query->whereHas('package', fn($q) => $q->where('name', $request->package));
        }

        return view('reservations.index', [
            'reservations' => $query->get(),
            'services' => Service::all(),
            'packages' => Package::all(),
        ]);
    }

    public function deleteReceiptImage(Request $request)
    {
        $reservation = Reservation::find($request->reservation_id);
        if ($reservation) {
            $images = json_decode($reservation->receipt_image, true);
            $images = array_values(array_diff($images, [$request->image]));
            $reservation->receipt_image = json_encode($images);
            $reservation->save();
            return response()->json(['success' => true]);
        }
        return response()->json(['success' => false]);
    }
}
