<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\MenuRating;
use App\Notifications\OrderCompletedNotification;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function __construct() {
        return $this->middleware('auth');
    }

    public function index() {
        $activeOrder = auth()->user()->orders()->where('completed', 0)->orderBy('dateTime', 'desc')->first();
        $allOrders = auth()->user()->orders()->orderBy('dateTime', 'desc')->paginate(8);
        return view('order', compact('activeOrder', 'allOrders'));
    }

    public function show(Order $order) {
        $activeOrder = $order;
        $allOrders = auth()->user()->orders()->orderBy('dateTime', 'desc')->paginate(8);
        return view('order', compact('activeOrder', 'allOrders'));
    }

    public function kitchenOrder() {
        if (auth()->user()->role == 'customer') abort(403, 'This route is only meant for restaurant staffs.');
        $activeOrders = Order::where('completed', 0)->orderBy('dateTime', 'desc')->paginate(8);
        $firstOrder = $activeOrders->first();
        return view('kitchenOrder', compact('firstOrder', 'activeOrders'));
    }

    public function specificKitchenOrder(Order $order) {
        if (auth()->user()->role == 'customer') abort(403, 'This route is only meant for restaurant staffs.');
        $activeOrders = Order::where('completed', 0)->orderBy('dateTime', 'desc')->paginate(8);
        $transactions = Transaction::with('order.user', 'order.cartItems.menu')->get();
        return view('kitchenOrder', compact('order', 'activeOrders', 'transactions'));
    }

    public function orderStatusUpdate(CartItem $orderItem) {
        if (auth()->user()->role == 'customer') abort(403, 'This route is only meant for restaurant staffs.');
        $orderItem->fulfilled = !$orderItem->fulfilled;
        $orderItem->save();

        $cartItems = CartItem::where('order_id', $orderItem->order_id)->paginate(8);
        foreach ($cartItems as $item) {
            if (!$item->fulfilled) return redirect()->route('kitchenOrder');
        }

        $orderItem->order->completed = true;
        $orderItem->push();
        $orderItem->order->user->notify(new OrderCompletedNotification($orderItem->order));

        return redirect()->route('kitchenOrder');
    }

    public function previousOrder() {
        if (auth()->user()->role == 'customer') abort(403, 'This route is only meant for restaurant staffs.');
        $previousOrders = Order::where('completed', 1)->orderBy('dateTime', 'desc')->paginate(8);
        $transactions = Transaction::with('order.user', 'order.cartItems.menu')->get();
        return view('previousOrder', compact('previousOrders', 'transactions'));
    }

    public function filterPreviousOrders(Request $request) {
        if (auth()->user()->role == 'customer') abort(403, 'This route is only meant for restaurant staffs.');
        
        $query = Order::where('completed', 1);
        if ($request->filled('orderID')) $query->where('id', $request->orderID);
        if ($request->filled('startDate') && $request->filled('endDate')) {
            $query->whereBetween('dateTime', [$request->startDate, $request->endDate]);
        }
        if ($request->filled('startTime') && $request->filled('endTime')) {
            $query->whereTime('dateTime', '>=', Carbon::parse($request->startTime)->format('H:i:s'))
                  ->whereTime('dateTime', '<=', Carbon::parse($request->endTime)->format('H:i:s'));
        }
        if ($request->filled('orderType')) $query->where('type', $request->orderType);
        
        $sortField = $request->filled('sortField') ? $request->sortField : 'dateTime';
        $sortOrder = $request->filled('sortOrder') && $request->sortOrder == 'asc' ? 'asc' : 'desc';
        $query->orderBy($sortField, $sortOrder);

        $previousOrders = $query->paginate(8);
        $transactions = Transaction::with('order.user', 'order.cartItems.menu')->get();

        return view('previousOrder', compact('previousOrders', 'transactions'));
    }

    public function storemenu(Request $request) {
        $request->validate([
            'ratings.*.menu_id' => 'required|exists:menus,id',
            'ratings.*.rating' => 'required|integer|between:1,5',
            'ratings.*.order_id' => 'required|exists:orders,id',
            'overall_comment' => 'nullable|string|max:255',
        ]);

        foreach ($request->ratings as $menuId => $ratingData) {
            $existingRating = MenuRating::where('menu_id', $ratingData['menu_id'])
                ->where('user_id', Auth::id())
                ->where('order_id', $ratingData['order_id'])
                ->first();

            if ($existingRating) {
                $existingRating->update([
                    'rating' => $ratingData['rating'],
                    'comment' => $request->overall_comment,
                ]);
            } else {
                MenuRating::create([
                    'menu_id' => $ratingData['menu_id'],
                    'user_id' => Auth::id(),
                    'order_id' => $ratingData['order_id'],
                    'rating' => $ratingData['rating'],
                    'comment' => $request->overall_comment,
                ]);
            }
        }

        return redirect()->back()->with('success', 'Ratings and comment submitted successfully!');
    }
}
